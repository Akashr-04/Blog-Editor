import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, File, X, CheckCircle } from 'lucide-react';
import { uploadDocument } from '../services/api';
import { useDocuments } from '../context/DocumentContext';

const UploadForm: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const { refreshDocuments } = useDocuments();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setFile(acceptedFiles[0]);
      setUploadError(null);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'text/plain': ['.txt'],
    },
    maxFiles: 1,
    multiple: false,
  });

  const handleUpload = async () => {
    if (!file) return;

    setIsUploading(true);
    setUploadError(null);
    
    try {
      await uploadDocument(file);
      setUploadSuccess(true);
      await refreshDocuments();
      setTimeout(() => {
        setFile(null);
        setUploadSuccess(false);
      }, 3000);
    } catch (error) {
      console.error('Upload error:', error);
      setUploadError('Failed to upload document. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  const removeFile = () => {
    setFile(null);
    setUploadError(null);
    setUploadSuccess(false);
  };

  return (
    <div className="card p-6 max-w-2xl mx-auto animate-fade-in">
      <h2 className="text-2xl font-semibold mb-4">Upload Document</h2>

      <div 
        {...getRootProps()} 
        className={`border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors ${
          isDragActive 
            ? 'border-primary-500 bg-primary-50' 
            : 'border-gray-300 hover:border-primary-400 hover:bg-gray-50'
        }`}
      >
        <input {...getInputProps()} />
        <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
        <p className="text-lg font-medium">Drag & drop a document here</p>
        <p className="text-gray-500 mt-2">or click to select a file</p>
        <p className="text-xs text-gray-400 mt-4">Supported formats: TXT</p>
      </div>

      {file && (
        <div className="mt-4 p-3 bg-gray-50 rounded-md flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <File className="w-5 h-5 text-primary-600" />
            <div>
              <p className="font-medium">{file.name}</p>
              <p className="text-sm text-gray-500">
                {file.size < 1024 * 1024
                  ? `${(file.size / 1024).toFixed(1)} KB`
                  : `${(file.size / (1024 * 1024)).toFixed(1)} MB`}
              </p>
            </div>
          </div>
          <button 
            onClick={removeFile} 
            className="text-gray-400 hover:text-gray-600"
            disabled={isUploading}
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      )}

      {uploadSuccess && (
        <div className="mt-4 p-3 bg-green-50 text-green-700 rounded-md flex items-center">
          <CheckCircle className="w-5 h-5 mr-2" />
          Document uploaded successfully! Processing has begun.
        </div>
      )}

      {uploadError && (
        <div className="mt-4 p-3 bg-red-50 text-red-700 rounded-md">
          {uploadError}
        </div>
      )}

      <div className="mt-6 flex justify-end">
        <button
          onClick={handleUpload}
          disabled={!file || isUploading}
          className={`btn btn-primary ${
            !file || isUploading ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        >
          {isUploading ? 'Uploading...' : 'Upload Document'}
        </button>
      </div>
    </div>
  );
};

export default UploadForm;