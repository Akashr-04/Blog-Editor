import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { askQuestion } from '../services/api';
import { QuestionAnswerType } from '../types';

interface QuestionFormProps {
  documentId: string;
  onAnswerReceived: (qa: QuestionAnswerType) => void;
  isLoading: boolean;
  setIsLoading: (isLoading: boolean) => void;
}

const QuestionForm: React.FC<QuestionFormProps> = ({
  documentId,
  onAnswerReceived,
  isLoading,
  setIsLoading,
}) => {
  const [question, setQuestion] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!question.trim() || isLoading) return;
    
    setIsLoading(true);
    
    try {
      const answer = await askQuestion(documentId, question);
      onAnswerReceived(answer);
      setQuestion('');
    } catch (error) {
      console.error('Error asking question:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="mt-4">
      <div className="relative">
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Ask a question about this document..."
          className="input pr-12"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={!question.trim() || isLoading}
          className={`absolute right-2 top-1/2 transform -translate-y-1/2 p-1.5 rounded-full
            ${
              question.trim() && !isLoading
                ? 'bg-primary-600 text-white hover:bg-primary-700'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </form>
  );
};

export default QuestionForm;