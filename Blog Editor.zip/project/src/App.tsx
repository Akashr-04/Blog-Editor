import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import BlogList from './pages/BlogList';
import BlogEditor from './pages/BlogEditor';

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<BlogList />} />
        <Route path="/editor" element={<BlogEditor />} />
        <Route path="/editor/:id" element={<BlogEditor />} />
      </Routes>
      <Toaster position="bottom-right" />
    </>
  );
}

export default App;