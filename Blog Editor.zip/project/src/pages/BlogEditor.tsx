import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { Save, Send, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';
import { saveDraft, publishBlog, getBlogById } from '../services/api';
import { BlogFormData } from '../types';

const BlogEditor: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [formData, setFormData] = useState<BlogFormData>({
    title: '',
    content: '',
    tags: '',
  });
  const [isSaving, setIsSaving] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  const editor = useEditor({
    extensions: [StarterKit],
    content: formData.content,
    onUpdate: ({ editor }) => {
      const newContent = editor.getHTML();
      setFormData(prev => ({ ...prev, content: newContent }));
      debouncedSave({ ...formData, content: newContent });
    },
  });

  useEffect(() => {
    if (id) {
      const loadBlog = async () => {
        try {
          const blog = await getBlogById(id);
          setFormData({
            title: blog.title,
            content: blog.content,
            tags: blog.tags.join(', '),
          });
          editor?.commands.setContent(blog.content);
        } catch (error) {
          toast.error('Failed to load blog');
          navigate('/');
        }
      };
      loadBlog();
    }
  }, [id, navigate, editor]);

  const debouncedSave = useCallback(
    debounce(async (data: BlogFormData) => {
      if (!data.title && !data.content) return;
      
      try {
        await saveDraft(data);
        toast.success('Draft saved');
      } catch (error) {
        toast.error('Failed to save draft');
      }
    }, 5000),
    []
  );

  const handleSave = async () => {
    if (!formData.title || !formData.content) {
      toast.error('Title and content are required');
      return;
    }

    setIsSaving(true);
    try {
      await saveDraft(formData);
      toast.success('Draft saved successfully');
    } catch (error) {
      toast.error('Failed to save draft');
    } finally {
      setIsSaving(false);
    }
  };

  const handlePublish = async () => {
    if (!formData.title || !formData.content) {
      toast.error('Title and content are required');
      return;
    }

    setIsPublishing(true);
    try {
      await publishBlog(formData);
      toast.success('Blog published successfully');
      navigate('/');
    } catch (error) {
      toast.error('Failed to publish blog');
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={() => navigate('/')}
          className="flex items-center text-gray-600 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </button>
        <div className="flex space-x-3">
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="btn btn-outline flex items-center"
          >
            <Save className="w-4 h-4 mr-2" />
            {isSaving ? 'Saving...' : 'Save Draft'}
          </button>
          <button
            onClick={handlePublish}
            disabled={isPublishing}
            className="btn btn-primary flex items-center"
          >
            <Send className="w-4 h-4 mr-2" />
            {isPublishing ? 'Publishing...' : 'Publish'}
          </button>
        </div>
      </div>

      <div className="space-y-4">
        <input
          type="text"
          value={formData.title}
          onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
          placeholder="Enter your blog title..."
          className="input text-2xl font-bold w-full"
        />

        <EditorContent
          editor={editor}
          className="min-h-[400px] prose max-w-none border rounded-lg p-4 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
        />

        <input
          type="text"
          value={formData.tags}
          onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
          placeholder="Enter tags (comma-separated)..."
          className="input"
        />
      </div>
    </div>
  );
};

// Debounce utility function
function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;

  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

export default BlogEditor;