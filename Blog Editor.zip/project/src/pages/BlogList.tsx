import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PenSquare, Clock, CheckCircle } from 'lucide-react';
import { format } from 'date-fns';
import { Blog } from '../types';
import { getBlogs } from '../services/api';

const BlogList: React.FC = () => {
  const navigate = useNavigate();
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadBlogs = async () => {
      try {
        const data = await getBlogs();
        setBlogs(data);
      } catch (error) {
        console.error('Failed to load blogs:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadBlogs();
  }, []);

  const drafts = blogs.filter(blog => blog.status === 'draft');
  const published = blogs.filter(blog => blog.status === 'published');

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">My Blogs</h1>
        <button
          onClick={() => navigate('/editor')}
          className="btn btn-primary flex items-center"
        >
          <PenSquare className="w-4 h-4 mr-2" />
          New Blog
        </button>
      </div>

      <div className="space-y-8">
        {drafts.length > 0 && (
          <section>
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <Clock className="w-5 h-5 mr-2 text-yellow-500" />
              Drafts
            </h2>
            <div className="space-y-4">
              {drafts.map(blog => (
                <BlogCard key={blog.id} blog={blog} />
              ))}
            </div>
          </section>
        )}

        {published.length > 0 && (
          <section>
            <h2 className="text-xl font-semibold mb-4 flex items-center">
              <CheckCircle className="w-5 h-5 mr-2 text-green-500" />
              Published
            </h2>
            <div className="space-y-4">
              {published.map(blog => (
                <BlogCard key={blog.id} blog={blog} />
              ))}
            </div>
          </section>
        )}

        {blogs.length === 0 && (
          <div className="text-center py-12">
            <PenSquare className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No blogs yet
            </h3>
            <p className="text-gray-500">
              Create your first blog by clicking the "New Blog" button above.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

interface BlogCardProps {
  blog: Blog;
}

const BlogCard: React.FC<BlogCardProps> = ({ blog }) => {
  const navigate = useNavigate();

  return (
    <div
      onClick={() => navigate(`/editor/${blog.id}`)}
      className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 hover:shadow-md transition-shadow cursor-pointer"
    >
      <div className="flex justify-between items-start mb-2">
        <h3 className="text-lg font-medium text-gray-900">{blog.title}</h3>
        <span className={`px-2 py-1 rounded text-sm ${
          blog.status === 'draft'
            ? 'bg-yellow-100 text-yellow-800'
            : 'bg-green-100 text-green-800'
        }`}>
          {blog.status}
        </span>
      </div>
      
      {blog.tags.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-3">
          {blog.tags.map(tag => (
            <span
              key={tag}
              className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-sm"
            >
              {tag}
            </span>
          ))}
        </div>
      )}
      
      <div className="text-sm text-gray-500">
        Last updated {format(new Date(blog.updatedAt), 'MMM d, yyyy h:mm a')}
      </div>
    </div>
  );
};

export default BlogList;