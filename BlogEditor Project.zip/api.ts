import axios from 'axios';
import { Blog, BlogFormData } from '../types';

const API_BASE_URL = 'http://localhost:3000/api';

// For development/demo purposes
const mockBlogs: Blog[] = [
  {
    id: '1',
    title: 'Getting Started with React',
    content: 'React is a powerful library for building user interfaces...',
    tags: ['react', 'javascript', 'frontend'],
    status: 'published',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const saveDraft = async (data: BlogFormData): Promise<Blog> => {
  // Mock implementation
  return new Promise((resolve) => {
    setTimeout(() => {
      const blog: Blog = {
        id: Math.random().toString(36).substring(2),
        title: data.title,
        content: data.content,
        tags: data.tags.split(',').map(tag => tag.trim()),
        status: 'draft',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      mockBlogs.push(blog);
      resolve(blog);
    }, 500);
  });
  
  // Production implementation
  // const response = await axios.post(`${API_BASE_URL}/blogs/save-draft`, data);
  // return response.data;
};

export const publishBlog = async (data: BlogFormData): Promise<Blog> => {
  // Mock implementation
  return new Promise((resolve) => {
    setTimeout(() => {
      const blog: Blog = {
        id: Math.random().toString(36).substring(2),
        title: data.title,
        content: data.content,
        tags: data.tags.split(',').map(tag => tag.trim()),
        status: 'published',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      mockBlogs.push(blog);
      resolve(blog);
    }, 500);
  });
  
  // Production implementation
  // const response = await axios.post(`${API_BASE_URL}/blogs/publish`, data);
  // return response.data;
};

export const getBlogs = async (): Promise<Blog[]> => {
  // Mock implementation
  return new Promise((resolve) => {
    setTimeout(() => resolve(mockBlogs), 500);
  });
  
  // Production implementation
  // const response = await axios.get(`${API_BASE_URL}/blogs`);
  // return response.data;
};

export const getBlogById = async (id: string): Promise<Blog> => {
  // Mock implementation
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const blog = mockBlogs.find(b => b.id === id);
      if (blog) {
        resolve(blog);
      } else {
        reject(new Error('Blog not found'));
      }
    }, 500);
  });
  
  // Production implementation
  // const response = await axios.get(`${API_BASE_URL}/blogs/${id}`);
  // return response.data;
};